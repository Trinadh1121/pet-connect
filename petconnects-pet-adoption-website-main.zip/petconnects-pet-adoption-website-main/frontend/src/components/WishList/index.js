import { Box, Text } from '@chakra-ui/react'
import React from 'react'

export const WishList = () => {
    return (
        <Box>
            <Text>WishList Component</Text>
        </Box>
    )
}
