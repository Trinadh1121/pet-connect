import { Box, Text } from '@chakra-ui/react'
import React from 'react'

export const Pet_details = () => {
    return (
        <Box>
            <Text>Pet_details Component</Text>
        </Box>
    )
}
